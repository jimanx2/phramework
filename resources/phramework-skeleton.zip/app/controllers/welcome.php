<?php namespace App\Controllers;

class Welcome extends Application {
  
  function home(){
    
  }
}