<?php namespace App\Controllers;

class Application extends \Phramework\Controllers\Application {

}