<?php

/* layouts/application.php */
class __TwigTemplate_818ef5bfc1c0a031231d615f0bb5c7066432de9d90a0f0c6fd49019cc6df2880 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html class=\"no-js\" lang=\"\">

<head>
    <title>Welcome To PhrameWork!</title>
</head>
</body>
    <h1>Welcome To PhrameWork!</h1>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "layouts/application.php";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html class="no-js" lang="">*/
/* */
/* <head>*/
/*     <title>Welcome To PhrameWork!</title>*/
/* </head>*/
/* </body>*/
/*     <h1>Welcome To PhrameWork!</h1>*/
/* </body>*/
/* </html>*/
/* */
