<?php 
/*
Examples:

  "/" => "pages#home"  // (redirects root to app/controllers/pages.php, action: home)
  "/:cntrl/:id-:page"  // $_GET['cntrl'], $_GET['id'], $_GET['page']
*/
$routes = [
];